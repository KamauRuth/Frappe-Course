import frappe
import random
import string
from frappe.model.document import Document

class AirplaneTicket(Document):

    def validate(self):
        self.calculate_total_amount()
        self.remove_duplicate_addons()

    def before_submit(self):
        if self.status != "Boarded":
            frappe.throw("You can only submit the ticket if status is Boarded")

    def calculate_total_amount(self):
        total_addons = 0
        for addon in self.add_ons:
            total_addons += addon.amount or 0

        self.total_amount = (self.flight_price or 0) + total_addons

    def remove_duplicate_addons(self):
        seen = set()
        unique_addons = []

        for addon in self.add_ons:
            if addon.item not in seen:
                seen.add(addon.item)
                unique_addons.append(addon)

        self.add_ons = unique_addons
    
	



    def validate(self):
        self.calculate_total_amount()
        self.remove_duplicate_addons()
        self.generate_seat()

    def generate_seat(self):
        # Generate random seat number (1-100)
        seat_number = random.randint(1, 100)
        # Generate random letter (A-E)
        seat_letter = random.choice(['A', 'B', 'C', 'D', 'E'])
        # Combine to create the seat value
        self.seat = f"{seat_number}{seat_letter}"