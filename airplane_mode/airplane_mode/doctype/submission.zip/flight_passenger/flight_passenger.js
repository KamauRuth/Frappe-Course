// Copyright (c) 2026, Kamau and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Flight Passenger", {
// 	refresh(frm) {

// 	},
// });
